<?php
    if ( !defined('ABSPATH' ) )
        exit();
?>

<div class="trp-settings-container trp-settings-container-ald_settings">
    <div id="tp-ald-popup-configurator-root"></div>
</div>
