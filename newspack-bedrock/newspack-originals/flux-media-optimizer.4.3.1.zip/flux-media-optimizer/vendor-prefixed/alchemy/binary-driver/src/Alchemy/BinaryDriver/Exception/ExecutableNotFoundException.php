<?php

/*
 * This file is part of Alchemy\BinaryDriver.
 *
 * (c) Alchemy <info@alchemy.fr>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace FluxMedia\Alchemy\BinaryDriver\Exception;

class ExecutableNotFoundException extends \RuntimeException implements ExceptionInterface
{
}
